import { Badge, Button, Container, Nav, Navbar } from 'react-bootstrap';

const navItems = [
  { href: '#categories', label: 'Danh mục' },
  { href: '#featured', label: 'Sách nổi bật' },
  { href: '#deals', label: 'Đơn hàng' },
  { href: '#support', label: 'Tư vấn' },
];

function Header({ cartCount }) {
  return (
    <Navbar expand="lg" className="site-header" sticky="top">
      <Container fluid className="px-0">
        <Navbar.Brand href="#home" className="brand">
          <span className="brand-mark">B</span>
          <span>
            <strong>BookNest</strong>
            <span>Chuyên trang sách trực tuyến</span>
          </span>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="bookstore-navigation" />

        <Navbar.Collapse id="bookstore-navigation">
          <Nav className="main-nav mx-auto">
            {navItems.map((item) => (
              <Nav.Link href={item.href} key={item.href}>
                {item.label}
              </Nav.Link>
            ))}
          </Nav>

          <Button className="cart-button" type="button" href="#deals">
            Giỏ hàng <Badge bg="light">{cartCount}</Badge>
          </Button>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;

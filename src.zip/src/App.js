import { useMemo, useState } from 'react';
import './App.css';
import CategoryStrip from './components/CategoryStrip';
import FeaturedBooks from './components/FeaturedBooks';
import Header from './components/Header';
import Hero from './components/Hero';
import OrderPanel from './components/OrderPanel';
import {
  books,
  categories,
  formatCurrency,
  startingCartItems,
} from './components/bookData';

function App() {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [sortBy, setSortBy] = useState('featured');
  const [cartItems, setCartItems] = useState(startingCartItems);

  const cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  const visibleBooks = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return books
      .filter((book) => {
        const matchesCategory =
          selectedCategory === 'Tất cả' || book.category === selectedCategory;
        const matchesQuery =
          !normalizedQuery ||
          [book.title, book.author, book.category].some((value) =>
            value.toLowerCase().includes(normalizedQuery),
          );

        return matchesCategory && matchesQuery;
      })
      .sort((firstBook, secondBook) => {
        if (sortBy === 'price-asc') {
          return firstBook.price - secondBook.price;
        }

        if (sortBy === 'rating') {
          return secondBook.rating - firstBook.rating;
        }

        if (sortBy === 'sold') {
          return secondBook.sold - firstBook.sold;
        }

        return firstBook.id - secondBook.id;
      });
  }, [query, selectedCategory, sortBy]);

  const detailedCartItems = cartItems
    .map((item) => {
      const book = books.find((currentBook) => currentBook.id === item.bookId);
      return book ? { ...book, quantity: item.quantity } : null;
    })
    .filter(Boolean);

  const handleAddToCart = (book) => {
    setCartItems((currentItems) => {
      const existingItem = currentItems.find((item) => item.bookId === book.id);

      if (existingItem) {
        return currentItems.map((item) =>
          item.bookId === book.id
            ? { ...item, quantity: Math.min(item.quantity + 1, book.stock) }
            : item,
        );
      }

      return [...currentItems, { bookId: book.id, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (bookId, direction) => {
    setCartItems((currentItems) =>
      currentItems
        .map((item) => {
          if (item.bookId !== bookId) {
            return item;
          }

          const book = books.find((currentBook) => currentBook.id === bookId);
          const nextQuantity =
            direction === 'increase' ? item.quantity + 1 : item.quantity - 1;

          return {
            ...item,
            quantity: Math.max(0, Math.min(nextQuantity, book?.stock || 1)),
          };
        })
        .filter((item) => item.quantity > 0),
    );
  };

  const handleRemoveItem = (bookId) => {
    setCartItems((currentItems) =>
      currentItems.filter((item) => item.bookId !== bookId),
    );
  };

  return (
    <div className="bookstore">
      <Header cartCount={cartCount} />

      <main>
        <Hero query={query} onQueryChange={setQuery} />

        <CategoryStrip
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        <section className="content-grid">
          <FeaturedBooks
            books={visibleBooks}
            formatCurrency={formatCurrency}
            onAddToCart={handleAddToCart}
            query={query}
            selectedCategory={selectedCategory}
            sortBy={sortBy}
            onQueryChange={setQuery}
            onSortChange={setSortBy}
          />

          <OrderPanel
            items={detailedCartItems}
            formatCurrency={formatCurrency}
            onRemoveItem={handleRemoveItem}
            onUpdateQuantity={handleUpdateQuantity}
          />
        </section>

        <section className="support-section" id="support">
          <div>
            <p className="eyebrow">Tư vấn chọn sách</p>
            <h2>Gợi ý theo nhu cầu đọc</h2>
            <p>
              BookNest gom các đầu sách theo mục tiêu học tập, làm việc và thư
              giãn để bạn chọn nhanh hơn thay vì lướt quá nhiều lựa chọn.
            </p>
          </div>

          <div className="support-grid">
            <article>
              <span>01</span>
              <strong>Bắt đầu thói quen đọc</strong>
              <p>Ưu tiên sách ngắn, chương rõ, dễ đọc 15 phút mỗi ngày.</p>
            </article>
            <article>
              <span>02</span>
              <strong>Nâng cấp công việc</strong>
              <p>Chọn sách kỹ năng, kinh tế và tư duy hệ thống có ví dụ thực tế.</p>
            </article>
            <article>
              <span>03</span>
              <strong>Quà tặng ý nghĩa</strong>
              <p>Lọc theo độ tuổi, chủ đề và thông điệp để tặng đúng người.</p>
            </article>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
